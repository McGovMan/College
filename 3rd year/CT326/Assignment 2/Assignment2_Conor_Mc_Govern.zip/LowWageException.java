// LowWageException class derived from Exception.

public class LowWageException extends Exception {

    // constructor
    public LowWageException(String message) {
        super(message);
    }

}
