rmiregistry -J-Djava.rmi.server.codebase=file:/home/conor/Workspace/College/CT414/Assignment_1/src/
