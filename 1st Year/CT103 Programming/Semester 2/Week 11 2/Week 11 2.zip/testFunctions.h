#ifndef __assert__testfunctions__
#define __assert__testfunctions__

long testGetLines();

long testGetSize();

long testGetChars();

int functions();

#endif /* defined(__assert__functions__) */