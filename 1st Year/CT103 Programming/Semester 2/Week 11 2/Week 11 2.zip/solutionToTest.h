#ifndef __assert__functions__
#define __assert__functions__

long getLines(char *fileName);
long getSize(char *fileName);
long getChars(char *fileName);

#endif /* defined(__assert__functions__) */
